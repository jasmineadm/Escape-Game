
package tools;


public class Objet {

	private String nom;
	private String description;
	
	
	public Objet(String nom, String description) {
	    this.nom = nom;
	    this.description = description;
	}

	public String getNom() {
	    return nom;
	}

	public String getDescription() {
	    return description;
	}
	

	
	
}